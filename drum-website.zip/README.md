# Drum Beats Website 🥁

Simple drum-themed website project for GitHub.

## Features
- Dark UI
- Drum info
- Button to play drum sound

## How to Use
Open index.html in your browser.

## Future Ideas
- Add real drum kit sounds
- Interactive drum pads
- Animations
